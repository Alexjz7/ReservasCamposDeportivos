﻿using Xunit;

namespace TestProject1
{
    public class ReservaShould
    {
        [Fact]
        public void ValidateUserReservas() 
        {
            //preparación, prueba, verificación
        var nombreBD = Guid.NewGuid().ToString();
            //var contexto = ConstruirContext(nombreBD);
        }
    }
}
